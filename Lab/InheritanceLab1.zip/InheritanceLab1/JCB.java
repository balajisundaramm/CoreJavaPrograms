public class JCB extends Vehicle
{
	public void drive()
	{
		System.out.println("JCB "+name+" being driven");	
	}
	public void showHand()
	{
		System.out.println("JCB "+name+" showing hand...bye...bye");	
	}

}
