public class Orangutan extends Animal
{
	public void eat()
	{
		System.out.println("orangu eating...in both the hands");	
	}
	public void sleep()
	{
		System.out.println("orangu sleeping.. like a man...");	
	}
	public void dance()
	{
		System.out.println("orangu dancing...break dance...");	
	}

}
