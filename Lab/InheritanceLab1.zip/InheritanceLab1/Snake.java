public class Snake extends Animal
{
	public void hiss()
	{
		System.out.println("Snake hissing...hisss..ussshss");	
	}
	public void eat()
	{
		System.out.println("Snake eating..by swallowing...");		
	}	
	public void dance()
	{
		System.out.println("Snake doing Snake dance!!!");	
	}

}
