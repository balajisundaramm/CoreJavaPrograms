public class Scooter extends Vehicle
{
	//override
	public void start()
	{
		System.out.println("Scooter "+name+" bending and starting...");
	}
	public void makeSound()
	{
		System.out.println("Scooter "+name+" making sound...iiiieheehhheeeeeee");
	}
}



