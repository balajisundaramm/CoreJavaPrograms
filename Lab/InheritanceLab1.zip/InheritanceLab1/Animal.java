public class Animal
{
	String name;
	public void eat()
	{
		System.out.println("animal eating...");	
	}
	public void sleep()
	{
		System.out.println("animal sleeping...zzz...zz");	
	}
	public void dance()
	{
		System.out.println("animal dancing...jinkalaka...");	
	}
}
