public class Dog extends Animal
{
	public void dance() //override!
	{
		System.out.println("Dog dancing on the floor...dance...");
	}
	public void bark()
	{
		System.out.println("Dog barking bow..bow");	
	}
}
